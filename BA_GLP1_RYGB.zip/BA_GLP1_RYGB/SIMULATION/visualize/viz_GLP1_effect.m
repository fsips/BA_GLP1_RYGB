%% Stomach empting rate vs GLP-1 concentration

vol = 200;
quick = 200;

GLP1_st = 0.1:0.1:10;
GLP1_act = 2:0.1:20;
