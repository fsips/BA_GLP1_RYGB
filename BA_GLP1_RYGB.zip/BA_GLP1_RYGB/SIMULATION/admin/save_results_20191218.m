
save '20191218_results' 'base_sim' 'grid' 'change_of_transit_RYGB' 'change_of_reflex_RYGB'